#!/bin/bash
#   hw3_hwhwang2/_____README
#			|
#			|_____run.bash 
#			|
#			|_____gendata.bash(This file)
#			|
#			|_____hw3_hwhwang2.pdf
#			|
#			|_____exp.xls
#			|
#			|_____python/
#			|
#			|_____ java/ 
# Takes hours to Gen
mkdir data
cd python
python gen1.py
python gen2.py
python gen3.py
python gen4.py
cd ..